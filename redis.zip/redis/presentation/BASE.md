<!-- *************** SLIDES BEGIN ********************* -->
******* Con puntos ******* 
<section data-markdown style="text-align: left;">
<script type="text/template">
## <center>Instalación en Centos 7<center>

- Descargar
- Compilar desde los fuentes
- No tiene dependencias a otras librerias
- Para comprobar la instalacion (make test) <span style="color:red;">requiere TCL</span> 

</script>
</section>
<!-- *************** SLIDES END ********************* -->

<!-- *************** SLIDES BEGIN ********************* -->
******* Con referencias ******* 
<section data-markdown>
<script type="text/template">
##RESTful Services

<span class="ref">  
* <sup>1</sup> Allen, Rob; O’Phinney, Matthew Weier. __"RESTful Services made easy with ZF2."__ January 2013.  [Restful services](http://akrabat.com/wp-content/uploads/PHPBNL13-Restful-services-made-easy-with-ZF2-Tutorial.pdf "Restful service.").
<span>
</script>
</section>
<!-- *************** SLIDES END ********************* -->

<!-- *************** SLIDES BEGIN ********************* -->
******* Con codigo ******* 
<section data-markdown style="text-align: left;">
<script type="text/template">
## <center>Librerias<center>

TCL 
- (https://www.tcl.tk/) Tcl (Tool Command Language) is a very powerful but easy to learn dynamic programming language, suitable for a very wide range of uses, 
including web and desktop applications, networking, administration, testing and many more.

```
sudo yum install tcl
```
</script>
</section>
<!-- *************** SLIDES END ********************* -->







<!-- *************** SLIDES BEGIN ********************* -->
******* Con puntos ******* 

<!-- *************** SLIDES END ********************* -->

<!-- *************** SLIDES BEGIN ********************* -->
******* Con puntos ******* 

<!-- *************** SLIDES END ********************* -->


