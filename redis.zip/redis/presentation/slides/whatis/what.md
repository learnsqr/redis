## <span class="mysql-color">Qué es una API</span>

API (Application Program Interface) es un conjunto de rutinas, protocolos, y herramientas 
para construir aplicaciones de software. 

Una buena API hace que sea más fácil desarrollar 
un programa, proporcionando todos los bloques de construcción y un conjunto de reglas
para hacerlos interactuar, con los que luego el desarrollador construye la aplicación.




