## <span class="mysql-color">SOAP</span>

- Presentan las operaciones ya creadas al desarrollador.
- Paquete de datos grande (XML)
- Las llamadas van por POST
- Puede ser Sin-estado o Con-estado
- Se basa en una WSDL (Web Service Definition Languge)
