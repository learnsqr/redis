## <span class="mysql-color">REST</span>

- Retorna datos, no expone metodos.
- Soporta XML, y JSON
- Usa los verbos HTTP
- Conección punto a punto
- Javascript friendly
- Sin-estado
