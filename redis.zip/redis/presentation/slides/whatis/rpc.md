## <span class="mysql-color">RPC</span>

- Los RPC trabajan sobre verbos.
- Requieren ue e cliente conozca el nombre del procedimiento
- Tiene parámetros específicos y orden específico
- Requiere una URI para cada método 




