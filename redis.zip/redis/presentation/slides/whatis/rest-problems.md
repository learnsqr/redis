## <span class="mysql-color">REST Problems?</span>

- Son dificiles de construir y mantener   
  ####_Los frameworks de PHP ya estan preparados para trabajar con API's_
- No es segura   
  ####_Hay unas precauciones que se deben seguir. También Oauth_.
- No hay standares strictos para API's REST
  #### _No. no hay. Pero hay unas guías básicas y unos conceptos sólidos y compartidos_.
- Los servicios REST no son confiables
  ####_Tanto como SOAP, si se trabaja con los headers apropiados, los codigos de respuesta y los mensajes de error_.
