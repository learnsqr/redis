## <span class="mysql-color">Una buena API</span>

- Generalidad
  
- Familiaridad
  
- Escalabilidad
  
- Segmentación

- Velocidad

- Seguridad

- Encapsulación
