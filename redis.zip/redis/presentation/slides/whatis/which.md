## <span class="mysql-color">Tipos de API</span>

- REST (Representational State Transfer)
- RPC (Remote Procedure Call)
- SOAP (Simple Object Access Protocol)




