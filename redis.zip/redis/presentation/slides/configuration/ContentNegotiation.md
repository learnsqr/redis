## <span class="mysql-color">Partes de una aPI</span>

* Content negotiation
* Error reporting
* Discovery
* Authentication
* Documentation
* HTTP method negotiation
* Versioning
* Validation
* Authorisation   

